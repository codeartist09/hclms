Upm
React js, Node js, Express js, Mongodb

npm install

for running backend:

npm start

for running frontend:

cd Frontend

npm start
