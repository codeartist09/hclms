const data = [{
    "_id": {
        "$oid": "61143ea388f17ea2875f2dcc"
    },
    "cart": [],
    "myCourses": [{
            "_id": "61148d404d9c2735ac95059d",
            "imageURL": "https://picsum.photos/200",
            "title": "Mental Health",
            "author": "Aristotle",
            "currPrice": 3434
        },
        {
            "_id": "61149d7d4d9c2735ac9505a3",
            "imageURL": "https://picsum.photos/200",
            "title": "Kidney Transplant surgery",
            "author": "John Doe",
            "currPrice": 120000
        },
        {
            "_id": "60d95a92a3092a1203b34b05",
            "imageURL": "https://picsum.photos/200",
            "title": "Learn to do Davinci heart surgery",
            "author": "Joe Biden",
            "currPrice": 10000
        },
        {
            "_id": "60e49c4c47cffde9e74b89fe",
            "imageURL": "/images/logo/lms/general_med.jpeg",
            "title": "General Medicine",
            "author": "Albert Einstein",
            "currPrice": 900000
        },
        {
            "_id": "611489684d9c2735ac95059b",
            "imageURL": "https://picsum.photos/200",
            "title": "Ear, Nose, Throat",
            "author": "Michael Jackson",
            "currPrice": 4550
        },
        {
            "_id": "611ad91c3fbd236bda0ffd89",
            "imageURL": "https://picsum.photos/200",
            "title": "Kidney treatment with vimeo",
            "author": "John Doe",
            "currPrice": 120000
        }
    ],
    "name": "Student 1",
    "email": "student1@gmail.com",
    "password": "$2a$10$McdwmIid2Cgd/qTKIfxSD.ilooegjX8s.TREzq4pzTVZmTD5H75hS",
    "usertype": "S",
    "__v": 4
}, {
    "_id": {
        "$oid": "611468ad6298c1c0d3bad323"
    },
    "cart": [],
    "myCourses": [],
    "name": "Student 2",
    "email": "student2@gmail.com",
    "password": "$2a$10$tTLJLYID9Nn9/q5KzqUQP.0fvP1PByIk.1Zkqj5uUjYWOIbCwJcJi",
    "usertype": "S",
    "__v": 0
}, {
    "_id": {
        "$oid": "61148e44a69ee3d382893ed9"
    },
    "cart": [{
        "_id": "60e49c4c47cffde9e74b89fe",
        "imageURL": "/images/logo/lms/general_med.jpeg",
        "title": "General Medicine",
        "author": "Albert Einstein",
        "currPrice": 900000
    }],
    "myCourses": [],
    "name": "Professor John",
    "email": "professor1@gmail.com",
    "password": "$2a$10$XLNx2aYxTWwtLwBn0AtLg.w3MZgjY2ayJG2qjHhOiWEW3W9emwuJO",
    "usertype": "I",
    "__v": 24
}];
